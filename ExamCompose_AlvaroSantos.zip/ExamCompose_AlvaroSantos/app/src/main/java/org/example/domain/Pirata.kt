package org.example.domain

data class Pirata(
    val nombre: String,
    val apellido: String,
    val buscado: Boolean = false
)
