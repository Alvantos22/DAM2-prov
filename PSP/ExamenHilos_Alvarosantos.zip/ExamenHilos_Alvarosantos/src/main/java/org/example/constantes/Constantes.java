package org.example.constantes;

public class Constantes {
    public static final int NUM_CASILLAS=100;
    public static final int NUM_JUGADORES=10;

}
