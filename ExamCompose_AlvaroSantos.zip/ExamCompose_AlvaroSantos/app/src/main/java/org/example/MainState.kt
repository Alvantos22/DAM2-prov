
package org.example

import androidx.compose.foundation.text.input.TextFieldState
import org.example.domain.Pirata
import org.example.domain.PirataDos

data class MainState(
    val pirata: Pirata = Pirata("", ""),
    val textStatePirata: TextFieldState = TextFieldState(),
    val pirataSeleccionado: Pirata? = null,
    val piratas: List<Pirata> = listOf(
        Pirata("Luffy", "Monkey D."),
        Pirata("Zoro", "Roronoa"),
        Pirata("Nami", "")
    ),
    //COSAS DEL DOS
    val pirataDos: PirataDos = PirataDos("", "", "", ""),
    val pirataDosSeleccionado: PirataDos? = null,
    val piratasDos: List<PirataDos> = listOf(
        PirataDos("Luffy", "Monkey D.", "Thousand Sunny", "Sombrero de Paja"),
        PirataDos("Shanks", "Figarland", "Red Force", "Piratas de Shanks"),
        PirataDos("Buggy", "Clown", "Big Top", "Cross Guild")
    )
)
