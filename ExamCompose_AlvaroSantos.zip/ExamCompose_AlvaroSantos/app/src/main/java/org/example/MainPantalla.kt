
package org.example

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import org.example.ui.ItemPirata
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Alignment
import kotlinx.coroutines.launch
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import org.example.domain.PirataDos
import org.example.ui.ItemPirataDos


@Composable
fun MainPantalla(modifier: Modifier = Modifier) {

    // Variables que recuerdan su valor
    var nombre by remember {
        mutableStateOf("")
    }

    var nombreGuardado by remember {
        mutableStateOf("")
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        // Titulo
        Text(text = "Mi primera aplicación")

        Spacer(modifier = Modifier.height(16.dp))

        // Cuadro de texto
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Boton
        Button(
            onClick = {
                nombreGuardado = nombre
            }
        ) {
            Text("Guardar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Resultado
        Text(
            text = "Nombre guardado: $nombreGuardado"
        )
    }
}

@Composable
fun PantallaPirata(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // Controla los mensajes Snackbar
    val snackbarHostState = remember {
        SnackbarHostState()
    }

    // Permite lanzar corrutinas
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { paddingValues ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "Lista de piratas",
                style = MaterialTheme.typography.headlineMedium
            )

            OutlinedTextField(
                value = state.pirata.nombre,
                onValueChange = { texto ->
                    viewModel.onChangePirata(
                        state.pirata.copy(nombre = texto)
                    )
                },
                label = { Text("Nombre") }
            )

            OutlinedTextField(
                state = state.textStatePirata,
                label = { Text("Apellido") }
            )

            Row {
                Button(
                    onClick = {
                        if (state.pirata.nombre.isNotBlank()) {
                            viewModel.onAddPirata()

                            scope.launch {
                                snackbarHostState.showSnackbar(
                                    "Pirata añadido correctamente"
                                )
                            }
                        }
                    }
                ) {
                    Text("Añadir pirata")
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        viewModel.onDeletePirata()
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                "Pirata añadido correctamente"
                            )
                        }

                    },
                    enabled = state.pirataSeleccionado != null
                ) {
                    Text("Borrar")
                }

            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(state.piratas) { pirata ->
                    ItemPirata(
                        pirata = pirata,
                        onClick = {
                            viewModel.onSelectPirata(pirata)
                        },
                        seleccionado = state.pirataSeleccionado == pirata,
                        onChangeBuscado = { marcado ->
                            viewModel.onChangeBuscado(pirata, marcado)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PantallaPirataDos(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    val snackbarHostState = remember {
        SnackbarHostState()
    }

    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { paddingValues ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "Gestión de piratas",
                style = MaterialTheme.typography.headlineMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = state.pirataDos.nombre,
                    onValueChange = {
                        viewModel.onChangePirataDos(
                            state.pirataDos.copy(nombre = it)
                        )
                    },
                    label = { Text("Nombre") }
                )

                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = state.pirataDos.apellido,
                    onValueChange = {
                        viewModel.onChangePirataDos(
                            state.pirataDos.copy(apellido = it)
                        )
                    },
                    label = { Text("Apellido") }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = state.pirataDos.nombreBarco,
                    onValueChange = {
                        viewModel.onChangePirataDos(
                            state.pirataDos.copy(nombreBarco = it)
                        )
                    },
                    label = { Text("Nombre barco") }
                )

                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = state.pirataDos.nombreTripulacion,
                    onValueChange = {
                        viewModel.onChangePirataDos(
                            state.pirataDos.copy(nombreTripulacion = it)
                        )
                    },
                    label = { Text("Tripulación") }
                )
            }

            Row {
                Button(
                    onClick = {
                        if (state.pirataDos.nombre.isNotBlank()) {
                            viewModel.onAddPirataDos()

                            scope.launch {
                                snackbarHostState.showSnackbar(
                                    "Pirata añadido correctamente"
                                )
                            }
                        }
                    }
                ) {
                    Text("Añadir")
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        viewModel.onDeletePirataDos()

                        scope.launch {
                            snackbarHostState.showSnackbar(
                                "Pirata borrado correctamente"
                            )
                        }
                    },
                    enabled = state.pirataDosSeleccionado != null
                ) {
                    Text("Borrar")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(state.piratasDos) { pirata ->
                    ItemPirataDos(
                        pirata = pirata,
                        onClick = {
                            viewModel.onSelectPirataDos(pirata)
                        },
                        seleccionado = state.pirataDosSeleccionado == pirata,
                        onChangeBuscado = { marcado ->
                            viewModel.onChangeBuscadoDos(pirata, marcado)
                        }
                    )
                }
            }
        }
    }
}