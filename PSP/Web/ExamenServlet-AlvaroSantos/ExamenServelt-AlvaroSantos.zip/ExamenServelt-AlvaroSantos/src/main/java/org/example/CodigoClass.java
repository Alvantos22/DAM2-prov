package org.example;

import config.config.ThymeleafConstants;
import config.config.UrlConstants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;
import java.io.IOException;


@WebServlet("/codigo")
public class CodigoClass extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var session = req.getSession();
        Integer n1 = Integer.parseInt(req.getParameter("n1"));
        Integer n2 = Integer.parseInt(req.getParameter("n2"));
        Integer n3 = Integer.parseInt(req.getParameter("n3"));
        Integer n4 = Integer.parseInt(req.getParameter("n4"));



        if (n1 == null||n2==null||n3==null||n4==null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST,"Introduce un codigo por parametro");
            return;
        }

        session.setAttribute("n1", n1);
        session.setAttribute("n2", n2);
        session.setAttribute("n3", n3);
        session.setAttribute("n4", n4);


        var webExchange = JakartaServletWebApplication.buildApplication(getServletContext())
                .buildExchange(req, resp);
        WebContext ctx = new WebContext(webExchange);
        ctx.setVariable("n1", n1 );
        ctx.setVariable("n2", n2 );
        ctx.setVariable("n3", n3 );
        ctx.setVariable("n4", n4 );

        resp.setContentType(ThymeleafConstants.CONTENT_TYPE);
        ((TemplateEngine)getServletContext().getAttribute(ThymeleafConstants.TEMPLATE_ENGINE_ATTR))
                .process(UrlConstants.TEMPLATE_Codigo, ctx, resp.getWriter());



    }
}