package org.example;

import config.ThymeleafConstants;
import config.UrlConstants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/tres")
public class RayaDeTres extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{

        String simbolo = req.getParameter("simbolo");
        String coordenada = req.getParameter("coordenada");
        Boolean turnos = (Boolean) req.getSession().getAttribute("turnos");

        if (simbolo==null || coordenada==null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST,"Eh tu mamonazo, parametro requerido");
            return;
        }

        if (turnos == null) {
            turnos = true;
        }


        String[] Tablero = (String[]) req.getSession().getAttribute("Tablero");
        if (Tablero==null) {
            Tablero = new String[]{"-", "-", "-", "-", "-", "-", "-", "-", "-"};
            req.getSession().setAttribute("Tablero",Tablero);

        }

        int posicion = Integer.parseInt(coordenada) - 1;
        if (!Tablero[posicion].equals("-")) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Eh tu mamonazo, Casilla ocupada");
            return;
        }
        if (posicion < 0 || posicion > 8) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Eh tu mamonazo, Coordenada inválida");
            return;
        }

        String turno = turnos ? "X" : "O";

        if (!turno.equals(simbolo)) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Eh tu mamonazo, no es tu turno");
            return;
        }else{
            turnos=!turnos;
           req.getSession().setAttribute("turnos",turnos);
        }

        Tablero[posicion]=simbolo;

        String fila1 = Tablero[0]+ " " + Tablero[1]+ " " + Tablero[2];
        String fila2 = Tablero[3]+ " " + Tablero[4]+ " " + Tablero[5];
        String fila3 = Tablero[6]+ " " + Tablero[7] + " " + Tablero[8];

        var webExchange = JakartaServletWebApplication.buildApplication(getServletContext())
                .buildExchange(req, resp);
        WebContext ctx = new WebContext(webExchange);
        ctx.setVariable("turno", turnos ? "X" : "O");
        ctx.setVariable("fila1", fila1);
        ctx.setVariable("fila2", fila2);
        ctx.setVariable("fila3", fila3);

        resp.setContentType(ThymeleafConstants.CONTENT_TYPE);
        ((TemplateEngine)getServletContext().getAttribute(ThymeleafConstants.TEMPLATE_ENGINE_ATTR))
                .process(UrlConstants.TEMPLATE_TRES_EN_RAYA, ctx, resp.getWriter());



    }
}
