package org.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.example.domain.Pirata

@Composable
fun ItemPirata(
    pirata: Pirata,
    onClick: () -> Unit,
    seleccionado: Boolean,
    onChangeBuscado: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable {
                onClick()
            },
        colors = CardDefaults.cardColors(
            containerColor = if (seleccionado)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = pirata.nombre)
                Text(text = pirata.apellido)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Buscado")

                Checkbox(
                    checked = pirata.buscado,
                    onCheckedChange = { marcado ->
                        onChangeBuscado(marcado)
                    }
                )
            }
        }
    }
}