
package org.example

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.*
import androidx.compose.foundation.text.input.TextFieldState
import androidx.compose.foundation.text.input.clearText
import org.example.domain.Pirata
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.example.domain.PirataDos

class MainViewModel : ViewModel() {

    private val _state = MutableStateFlow(MainState())

    val state: StateFlow<MainState> = _state.asStateFlow()

    // Cambiar el nombre del pirata
    fun onChangePirata(pirata: Pirata) {
        _state.update {
            it.copy(pirata = pirata)
        }
    }

    // Añadir pirata
    fun onAddPirata() {

        val nuevoPirata = _state.value.pirata.copy(
            apellido = _state.value.textStatePirata.text.toString()
        )

        if (nuevoPirata.nombre.isNotBlank()) {

            _state.update {
                it.copy(
                    piratas = it.piratas + nuevoPirata,
                    pirata = Pirata("", "")
                )
            }

            _state.value.textStatePirata.clearText()
        }
    }

    // Eliminar pirata
    fun onBorrarPirata(pirata: Pirata) {
        _state.update {
            it.copy(
                piratas = it.piratas.filterNot {
                        elemento -> elemento == pirata
                }
            )
        }
    }

    fun onSelectPirata(pirata: Pirata) {
        _state.update {
            it.copy(pirataSeleccionado = pirata)
        }
    }

    fun onDeletePirata() {
        val seleccionado = _state.value.pirataSeleccionado

        if (seleccionado != null) {
            _state.update {
                it.copy(
                    piratas = it.piratas.filterNot { pirata ->
                        pirata == seleccionado
                    },
                    pirataSeleccionado = null
                )
            }
        }
    }


    fun onChangeBuscado(pirata: Pirata, buscado: Boolean) {
        val actualizado = pirata.copy(buscado = buscado)

        _state.update { estado ->
            estado.copy(
                piratas = estado.piratas.map {
                    if (it == pirata) actualizado else it
                },
                pirataSeleccionado = if (estado.pirataSeleccionado == pirata)
                    actualizado
                else
                    estado.pirataSeleccionado
            )
        }
    }


    //COSAS DEL DOS

    fun onChangePirataDos(pirata: PirataDos) {
        _state.update {
            it.copy(pirataDos = pirata)
        }
    }

    fun onAddPirataDos() {
        val nuevoPirata = _state.value.pirataDos

        if (nuevoPirata.nombre.isNotBlank()) {
            _state.update {
                it.copy(
                    piratasDos = it.piratasDos + nuevoPirata,
                    pirataDos = PirataDos("", "", "", "")
                )
            }
        }
    }

    fun onSelectPirataDos(pirata: PirataDos) {
        _state.update {
            it.copy(pirataDosSeleccionado = pirata)
        }
    }

    fun onDeletePirataDos() {
        val seleccionado = _state.value.pirataDosSeleccionado

        if (seleccionado != null) {
            _state.update {
                it.copy(
                    piratasDos = it.piratasDos.filterNot {
                            pirata -> pirata == seleccionado
                    },
                    pirataDosSeleccionado = null
                )
            }
        }
    }

    fun onChangeBuscadoDos(pirata: PirataDos, buscado: Boolean) {
        val actualizado = pirata.copy(buscado = buscado)

        _state.update { estado ->
            estado.copy(
                piratasDos = estado.piratasDos.map {
                    if (it == pirata) actualizado else it
                },
                pirataDosSeleccionado =
                    if (estado.pirataDosSeleccionado == pirata) actualizado
                    else estado.pirataDosSeleccionado
            )
        }
    }
}
