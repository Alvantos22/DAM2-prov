package org.example.domain

data class PirataDos(
    val nombre: String,
    val apellido: String,
    val nombreBarco: String,
    val nombreTripulacion: String,
    val buscado: Boolean = false
)