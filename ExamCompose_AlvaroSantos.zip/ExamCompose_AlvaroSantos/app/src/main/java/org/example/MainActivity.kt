package org.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.examcompose_alvarosantos.ui.theme.ExamCompose_AlvaroSantosTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ExamCompose_AlvaroSantosTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                   PantallaPirata(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun MainPantallaPreview() {
    ExamCompose_AlvaroSantosTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            MainPantalla(
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}


@Preview(showBackground = true)
@Composable
fun PantallaPirataPreview() {
    ExamCompose_AlvaroSantosTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            PantallaPirata(
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PantallaPirataDosPreview() {
    ExamCompose_AlvaroSantosTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            PantallaPirataDos(
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}